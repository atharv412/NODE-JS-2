import { area } from "./rectangle.js";


console.log("Area of rectangle"+area(2,3));
