// const http= require('http')

import { log } from "console";

// // import * as http from 'http';
// try {
//     http.createServer((req,res)=>{
//         res.writeHead(200,
//             {
//                 'Content-Type':'text/html'
//             }
//         )
//         res.end("Hello World")
//     }).listen(8000)
//     console.log("server listening on port 8000");
// } catch (error) {
//     console.log(error);
// }

