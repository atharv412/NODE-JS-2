

export function fact (x) {
    const a=x;
    let sum=1;
    for (let i = 1; i <= x; i++) {
        sum *=i        
    }
    // console.log(sum);
    return sum
}

export function nameCalcAge(fname,lname,dob)
{
    const fullName=fname+lname
    const d=new Date
// console.log(d.getFullYear());
    const currentAge=d.getFullYear()-dob;
return [fullName,currentAge]
}