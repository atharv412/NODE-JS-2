export function area(l,w) {
    return l*w
}
