import{area, circumfernce} from './circle.js'

console.log("area of circle"+area(3));

console.log("cirumfernce of circle"+circumfernce(3));

