import { fact } from "./index.js";

console.log("factorail of a number"+fact(5));
