import readline from 'node:readline';
import { nameCalcAge } from './index.js';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

p
rl.question(`What's your name?`, fname,lastname,dob => {
  // console.log(`Hi ${name}!`);
  const a=nameCalcAge(fname,lastname,dob)
console.log(a);

  rl.close();
});
