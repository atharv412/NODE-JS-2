import { createServer } from "http";

try {
    createServer((req, res) => {
        res.writeHead(200,
            {
                'Content-Type': 'text/html'
            }
        )
        const text1 = 'hello world'
        const final = text1.toLowerCase()
        res.end(`previous text:${text1} \n formatted text:${final}`)
    }).listen(8000)
    console.log("server listening on port 8000");
} catch (error) {
console.log(error);

}