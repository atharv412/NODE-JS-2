// import mysql from'node_modules/@types/mysql/index'

import mysql from 'mysql2';

const con=mysql.createConnection({
    user:"root",
    password:"root",
    database:"atharva"
});

con.connect(err=>{
    if(err) throw err

    // const sql="create table student(rno int, sname varchar(40), percentage int );"
    // con.query(sql,(err,res)=>{
    //     if(err) throw err
    //     console.log(`${res.affectedRows} table created`);
    // })
    con.query("insert into student values(3,'zxcvb',80);",(err,res)=>{
        if(err) throw err
        console.log(`${res.affectedRows} record inserted `);
    })
    // con.query("UPDATE student SET percentage = 90 WHERE rno = 1")

    con.end(()=>{
        if(err) throw err
        console.log(`connection closed`);
    })
})