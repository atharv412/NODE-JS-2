import {appendFile, readFile} from 'fs/promises'
import  fs from 'fs';
async function insertFile(path,data){
    try {
        const writitingData=await readFile(data,'utf-8',(err,data)=>{
            console.log(data);
        })
        await appendFile(path,writitingData)
    } catch (error) {
        console.log(error);
    }
}

insertFile("./test.txt","./test2.txt")