export function area(radius){
    return Math.PI*radius*radius
}

export function circumfernce(radius){
    return 2*Math.PI*radius
}