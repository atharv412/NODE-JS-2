import {area,circumfernce} from './circle.js'


console.log(`the area of given circle is ${area(4)}`);
console.log(`the area of given circle is ${circumfernce(4)}`);

