import readline from 'node:readline';

const buf1=Buffer.alloc(100)

let rl = readline.createInterface(
    process.stdin,
    process.stdout
);

rl.setPrompt(`Choices 1.concat 2.compare 3.copy\n enter choice`);
rl.prompt()
rl.on('line', (input) => {
    do{
        switch (input) {
            case 1://concat option
            rl.on('line',(input1)=>{
                let tempBuf=Buffer.from(input1)
                buf1=Buffer.concat([buf1,tempBuf])
                console.log(buf1.toString('ascii'));
                rl.close
            })
                break;
        
            case 2:
                rl.on('line',(input2)=>{
                    let tempBuf=Buffer.from(input2)
                    const x=Buffer.compare(buf1,tempBuf)
                    console.log("the difference between given value and the buffer is "+x);
                    rl.close()
                })
                break;

            case 3:
                break;
        }

    }while(input<3)
    rl.close()
})